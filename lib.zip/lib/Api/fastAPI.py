# from fastapi import FastAPI, File, UploadFile, Form, HTTPException
# from fastapi.middleware.cors import CORSMiddleware
# import cv2
# import numpy as np
# import torch
# from facenet_pytorch import MTCNN, InceptionResnetV1
# import pickle
# from datetime import datetime
# import os
# from typing import Dict, List
# import json
# from pathlib import Path

# app = FastAPI()

# # CORS configuration
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Configuration - Using proper path handling
# BASE_DIR = Path(__file__).parent
# EMBEDDING_PATH = BASE_DIR / "face_embeddings.pkl"
# ATTENDANCE_FILE = BASE_DIR / "attendance_records.json"
# FACES_DIR = BASE_DIR / "faces"

# # Create directories if they don't exist
# FACES_DIR.mkdir(exist_ok=True)

# # Initialize models
# device = 'cuda' if torch.cuda.is_available() else 'cpu'
# mtcnn = MTCNN(image_size=160, margin=20, min_face_size=40, device=device, keep_all=True)
# resnet = InceptionResnetV1(pretrained='vggface2').eval().to(device)

# # Load data
# def load_embeddings():
#     try:
#         if EMBEDDING_PATH.exists():
#             with open(EMBEDDING_PATH, 'rb') as f:
#                 return pickle.load(f)
#     except Exception as e:
#         print(f"Error loading embeddings: {e}")
#     return {}

# def load_attendance():
#     try:
#         if ATTENDANCE_FILE.exists():
#             with open(ATTENDANCE_FILE, 'r') as f:
#                 return json.load(f)
#     except Exception as e:
#         print(f"Error loading attendance: {e}")
#     return []

# #driver code
# db = load_embeddings()
# attendance_records = load_attendance()

# @app.post("/register")
# async def register_face(name: str = Form(...), image: UploadFile = File(...)):
#     contents = await image.read()
#     img = cv2.imdecode(np.frombuffer(contents, np.uint8), cv2.IMREAD_COLOR)
#     img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
#     faces = mtcnn(img)
#     if faces is None:
#         raise HTTPException(status_code=400, detail="No face detected")
    
#     embedding = resnet(faces[0].unsqueeze(0).to(device)).detach().cpu()
#     db[name] = embedding
    
#     # Save embeddings
#     with open(EMBEDDING_PATH, 'wb') as f:
#         pickle.dump(db, f)
    
#     # Save sample image
#     cv2.imwrite(str(FACES_DIR / f"{name}.jpg"), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
    
#     return {"status": "success", "message": f"{name} registered successfully"}

# @app.post("/recognize")
# async def recognize_face(image: UploadFile = File(...)):
#     contents = await image.read()
#     img = cv2.imdecode(np.frombuffer(contents, np.uint8), cv2.IMREAD_COLOR)
#     img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
#     faces = mtcnn(img)
#     if faces is None:
#         return {"status": "error", "message": "No faces detected"}
    
#     current_embeddings = resnet(faces.to(device)).detach().cpu()
#     names = list(db.keys())
#     embeddings = torch.stack(list(db.values())).squeeze(1)
    
#     results = []
#     for i, emb in enumerate(current_embeddings):
#         dists = torch.norm(embeddings - emb, dim=1)
#         min_dist, idx = torch.min(dists, dim=0)
        
#         if min_dist < 0.7:
#             name = names[idx]
#             results.append({
#                 "name": name,
#                 "confidence": float(1 - min_dist),
#                 "status": "recognized"
#             })
#         else:
#             results.append({
#                 "name": "Unknown",
#                 "confidence": 0.0,
#                 "status": "unknown"
#             })
    
#     return {"status": "success", "results": results}

# @app.post("/mark_attendance")
# async def mark_attendance(data: dict):
#     name = data.get("name")
#     if not name:
#         raise HTTPException(status_code=400, detail="Name is required")
    
#     timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
#     # Find or create today's record
#     today = datetime.now().strftime("%Y-%m-%d")
#     record = next((r for r in attendance_records if r["date"] == today), None)
    
#     if not record:
#         record = {
#             "date": today,
#             "present": [],
#             "absent": list(db.keys())
#         }
#         attendance_records.append(record)
    
#     if name not in record["present"]:
#         record["present"].append(name)
#         if name in record["absent"]:
#             record["absent"].remove(name)
        
#         # Save attendance
#         with open(ATTENDANCE_FILE, 'w') as f:
#             json.dump(attendance_records, f, indent=4)
        
#         return {"status": "success", "message": f"{name} marked present"}
    
#     return {"status": "info", "message": f"{name} already marked"}

# @app.get("/attendance")
# async def get_attendance():
#     return {"status": "success", "data": attendance_records}

# @app.get("/students")
# async def get_students():
#     return {"status": "success", "data": list(db.keys())}

# @app.delete("/students/{student_name}")
# async def delete_student(student_name: str):
#     global db, attendance_records
    
#     if student_name not in db:
#         raise HTTPException(status_code=404, detail="Student not found")
    
#     try:
#         # Remove student from database
#         del db[student_name]
        
#         # Save updated embeddings
#         with open(EMBEDDING_PATH, 'wb') as f:
#             pickle.dump(db, f)
        
#         # Delete student's face image if exists
#         face_image = FACES_DIR / f"{student_name}.jpg"
#         if face_image.exists():
#             face_image.unlink()
        
#         # Update attendance records
#         updated_records = []
#         for record in attendance_records:
#             # Create new present/absent lists without the student
#             present = [name for name in record['present'] if name != student_name]
#             absent = [name for name in record['absent'] if name != student_name]
            
#             # Only keep records that still have students
#             if present or absent:
#                 updated_records.append({
#                     "date": record["date"],
#                     "present": present,
#                     "absent": absent
#                 })
        
#         attendance_records = updated_records
        
#         # Save updated attendance
#         with open(ATTENDANCE_FILE, 'w') as f:
#             json.dump(attendance_records, f, indent=4)
        
#         return {"status": "success", "message": f"Student {student_name} deleted successfully"}
    
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error deleting student: {str(e)}")

# @app.delete("/reset-all")
# async def reset_all_data():
#     global db, attendance_records
    
#     try:
#         # Reset face embeddings
#         db = {}
#         with open(EMBEDDING_PATH, 'wb') as f:
#             pickle.dump(db, f)
        
#         # Reset attendance records
#         attendance_records = []
#         with open(ATTENDANCE_FILE, 'w') as f:
#             json.dump(attendance_records, f)
        
#         # Delete all face images
#         for file_path in FACES_DIR.glob("*"):
#             try:
#                 if file_path.is_file():
#                     file_path.unlink()
#             except Exception as e:
#                 print(f"Error deleting {file_path}: {e}")
        
#         return {"status": "success", "message": "All data reset successfully"}
    
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error resetting data: {str(e)}")

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="192.168.31.229", port=8000)






# from fastapi import FastAPI, File, UploadFile, Form, HTTPException
# from fastapi.middleware.cors import CORSMiddleware
# import cv2
# import numpy as np
# import torch
# from facenet_pytorch import MTCNN, InceptionResnetV1
# import pickle
# from datetime import datetime
# import os
# from typing import Dict, List
# import json
# from pathlib import Path

# app = FastAPI()

# # CORS configuration
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Configuration - Using proper path handling
# BASE_DIR = Path(__file__).parent
# EMBEDDING_PATH = BASE_DIR / "face_embeddings.pkl"
# ATTENDANCE_FILE = BASE_DIR / "attendance_records.json"
# FACES_DIR = BASE_DIR / "faces"

# # Create directories if they don't exist
# FACES_DIR.mkdir(exist_ok=True)

# # Initialize models
# device = 'cuda' if torch.cuda.is_available() else 'cpu'
# mtcnn = MTCNN(image_size=160, margin=20, min_face_size=40, device=device, keep_all=True)
# resnet = InceptionResnetV1(pretrained='vggface2').eval().to(device)

# # Load data
# def load_embeddings():
#     try:
#         if EMBEDDING_PATH.exists():
#             with open(EMBEDDING_PATH, 'rb') as f:
#                 return pickle.load(f)
#     except Exception as e:
#         print(f"Error loading embeddings: {e}")
#     return {}

# def load_attendance():
#     try:
#         if ATTENDANCE_FILE.exists():
#             with open(ATTENDANCE_FILE, 'r') as f:
#                 return json.load(f)
#     except Exception as e:
#         print(f"Error loading attendance: {e}")
#     return []

# # Initialize databases
# db = load_embeddings()
# attendance_records = load_attendance()

# @app.post("/register")
# async def register_face(name: str = Form(...), image: UploadFile = File(...)):
#     contents = await image.read()
#     img = cv2.imdecode(np.frombuffer(contents, np.uint8), cv2.IMREAD_COLOR)
#     img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
#     faces = mtcnn(img)
#     if faces is None:
#         raise HTTPException(status_code=400, detail="No face detected")
    
#     embedding = resnet(faces[0].unsqueeze(0).to(device)).detach().cpu()
#     db[name] = embedding
    
#     # Save embeddings
#     with open(EMBEDDING_PATH, 'wb') as f:
#         pickle.dump(db, f)
    
#     # Save sample image
#     cv2.imwrite(str(FACES_DIR / f"{name}.jpg"), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
    
#     return {"status": "success", "message": f"{name} registered successfully"}

# @app.post("/recognize")
# async def recognize_face(image: UploadFile = File(...)):
#     contents = await image.read()
#     img = cv2.imdecode(np.frombuffer(contents, np.uint8), cv2.IMREAD_COLOR)
#     img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
#     faces = mtcnn(img)
#     if faces is None:
#         return {"status": "error", "message": "No faces detected"}
    
#     current_embeddings = resnet(faces.to(device)).detach().cpu()
#     names = list(db.keys())
#     embeddings = torch.stack(list(db.values())).squeeze(1)
    
#     results = []
#     for i, emb in enumerate(current_embeddings):
#         dists = torch.norm(embeddings - emb, dim=1)
#         min_dist, idx = torch.min(dists, dim=0)
        
#         if min_dist < 0.7:
#             name = names[idx]
#             results.append({
#                 "name": name,
#                 "confidence": float(1 - min_dist),
#                 "status": "recognized",
#                 "position": {  # Adding position information for bounding boxes
#                     "left": 0.3,  # These should be calculated from face detection
#                     "top": 0.3,   # Replace with actual coordinates from MTCNN
#                     "width": 0.4,
#                     "height": 0.4
#                 }
#             })
#         else:
#             results.append({
#                 "name": "Unknown",
#                 "confidence": 0.0,
#                 "status": "unknown",
#                 "position": {
#                     "left": 0.3,
#                     "top": 0.3,
#                     "width": 0.4,
#                     "height": 0.4
#                 }
#             })
    
#     return {"status": "success", "results": results}

# @app.post("/mark_attendance")
# async def mark_attendance(data: dict):
#     name = data.get("name")
#     session_time_str = data.get("session_time")
    
#     if not name:
#         raise HTTPException(status_code=400, detail="Name is required")
    
#     try:
#         session_time = datetime.fromisoformat(session_time_str) if session_time_str else datetime.now()
#     except ValueError:
#         session_time = datetime.now()
    
#     timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
#     # Create a unique session ID based on date and hour-minute
#     session_id = f"{session_time.date()}_{session_time.hour}_{session_time.minute}"
    
#     # Find or create session record
#     session_record = next((r for r in attendance_records if r.get("session_id") == session_id), None)
    
#     if not session_record:
#         session_record = {
#             "session_id": session_id,
#             "date": session_time.strftime("%Y-%m-%d"),
#             "start_time": session_time.strftime("%H:%M"),
#             "present": [],
#             "absent": list(db.keys())
#         }
#         attendance_records.append(session_record)
    
#     if name not in session_record["present"]:
#         session_record["present"].append(name)
#         if name in session_record["absent"]:
#             session_record["absent"].remove(name)
        
#         # Save attendance
#         with open(ATTENDANCE_FILE, 'w') as f:
#             json.dump(attendance_records, f, indent=4)
        
#         return {"status": "success", "message": f"{name} marked present at {timestamp}"}
    
#     return {"status": "info", "message": f"{name} already marked in this session"}

# # Existing APIs remain unchanged below this point
# @app.get("/attendance")
# async def get_attendance():
#     return {"status": "success", "data": attendance_records}

# @app.get("/students")
# async def get_students():
#     return {"status": "success", "data": list(db.keys())}

# @app.delete("/students/{student_name}")
# async def delete_student(student_name: str):
#     global db, attendance_records
    
#     if student_name not in db:
#         raise HTTPException(status_code=404, detail="Student not found")
    
#     try:
#         # Remove student from database
#         del db[student_name]
        
#         # Save updated embeddings
#         with open(EMBEDDING_PATH, 'wb') as f:
#             pickle.dump(db, f)
        
#         # Delete student's face image if exists
#         face_image = FACES_DIR / f"{student_name}.jpg"
#         if face_image.exists():
#             face_image.unlink()
        
#         # Update attendance records
#         updated_records = []
#         for record in attendance_records:
#             # Create new present/absent lists without the student
#             present = [name for name in record.get('present', []) if name != student_name]
#             absent = [name for name in record.get('absent', []) if name != student_name]
            
#             # Only keep records that still have students
#             if present or absent:
#                 updated_record = {
#                     "date": record["date"],
#                     "present": present,
#                     "absent": absent
#                 }
#                 if "session_id" in record:
#                     updated_record["session_id"] = record["session_id"]
#                     updated_record["start_time"] = record["start_time"]
#                 updated_records.append(updated_record)
        
#         attendance_records = updated_records
        
#         # Save updated attendance
#         with open(ATTENDANCE_FILE, 'w') as f:
#             json.dump(attendance_records, f, indent=4)
        
#         return {"status": "success", "message": f"Student {student_name} deleted successfully"}
    
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error deleting student: {str(e)}")

# @app.delete("/reset-all")
# async def reset_all_data():
#     global db, attendance_records
    
#     try:
#         # Reset face embeddings
#         db = {}
#         with open(EMBEDDING_PATH, 'wb') as f:
#             pickle.dump(db, f)
        
#         # Reset attendance records
#         attendance_records = []
#         with open(ATTENDANCE_FILE, 'w') as f:
#             json.dump(attendance_records, f)
        
#         # Delete all face images
#         for file_path in FACES_DIR.glob("*"):
#             try:
#                 if file_path.is_file():
#                     file_path.unlink()
#             except Exception as e:
#                 print(f"Error deleting {file_path}: {e}")
        
#         return {"status": "success", "message": "All data reset successfully"}
    
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error resetting data: {str(e)}")

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="192.168.75.151", port=8000)







from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import cv2
import numpy as np
import torch
from facenet_pytorch import MTCNN, InceptionResnetV1
from pymongo import MongoClient
from bson.binary import Binary
import pickle
from datetime import datetime
from typing import Dict, List
from bson import ObjectId
import json

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# MongoDB configuration
MONGODB_URI = "mongodb://localhost:27017/"
DATABASE_NAME = "attendance_system"
EMBEDDINGS_COLLECTION = "face_embeddings"
ATTENDANCE_COLLECTION = "attendance_records"
FACES_COLLECTION = "face_images"

# Initialize MongoDB client
client = MongoClient(MONGODB_URI)
db = client[DATABASE_NAME]
embeddings_collection = db[EMBEDDINGS_COLLECTION]
attendance_collection = db[ATTENDANCE_COLLECTION]
faces_collection = db[FACES_COLLECTION]

# Initialize models
device = 'cuda' if torch.cuda.is_available() else 'cpu'
mtcnn = MTCNN(image_size=160, margin=20, min_face_size=40, device=device, keep_all=True)
resnet = InceptionResnetV1(pretrained='vggface2').eval().to(device)

def load_embeddings():
    embeddings = {}
    for record in embeddings_collection.find():
        embeddings[record['name']] = pickle.loads(record['embedding'])
    return embeddings

def load_attendance():
    records = list(attendance_collection.find({}, {'_id': 0}))
    # Convert ObjectId to string for JSON serialization
    for record in records:
        if 'session_id' in record:
            record['session_id'] = str(record['session_id'])
    return records

# Initialize databases
db = load_embeddings()
attendance_records = load_attendance()

@app.post("/register")
async def register_face(name: str = Form(...), image: UploadFile = File(...)):
    contents = await image.read()
    img = cv2.imdecode(np.frombuffer(contents, np.uint8), cv2.IMREAD_COLOR)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    faces = mtcnn(img)
    if faces is None:
        raise HTTPException(status_code=400, detail="No face detected")
    
    embedding = resnet(faces[0].unsqueeze(0).to(device)).detach().cpu()
    
    # Convert embedding tensor to binary for MongoDB storage
    embedding_bin = Binary(pickle.dumps(embedding))
    
    # Store in MongoDB
    embeddings_collection.update_one(
        {'name': name},
        {'$set': {'name': name, 'embedding': embedding_bin}},
        upsert=True
    )
    
    # Store face image in MongoDB
    _, img_encoded = cv2.imencode('.jpg', cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
    faces_collection.update_one(
        {'name': name},
        {'$set': {'name': name, 'image': Binary(img_encoded.tobytes())}},
        upsert=True
    )
    
    # Update in-memory db
    db[name] = embedding
    
    return {"status": "success", "message": f"{name} registered successfully"}

@app.post("/recognize")
async def recognize_face(image: UploadFile = File(...)):
    contents = await image.read()
    img = cv2.imdecode(np.frombuffer(contents, np.uint8), cv2.IMREAD_COLOR)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    faces = mtcnn(img)
    if faces is None:
        return {"status": "error", "message": "No faces detected"}
    
    current_embeddings = resnet(faces.to(device)).detach().cpu()
    names = list(db.keys())
    embeddings = torch.stack(list(db.values())).squeeze(1)
    
    results = []
    for i, emb in enumerate(current_embeddings):
        dists = torch.norm(embeddings - emb, dim=1)
        min_dist, idx = torch.min(dists, dim=0)
        
        if min_dist < 0.7:
            name = names[idx]
            results.append({
                "name": name,
                "confidence": float(1 - min_dist),
                "status": "recognized",
                "position": {
                    "left": 0.3,
                    "top": 0.3,
                    "width": 0.4,
                    "height": 0.4
                }
            })
        else:
            results.append({
                "name": "Unknown",
                "confidence": 0.0,
                "status": "unknown",
                "position": {
                    "left": 0.3,
                    "top": 0.3,
                    "width": 0.4,
                    "height": 0.4
                }
            })
    
    return {"status": "success", "results": results}

@app.post("/mark_attendance")
async def mark_attendance(data: dict):
    name = data.get("name")
    session_time_str = data.get("session_time")
    
    if not name:
        raise HTTPException(status_code=400, detail="Name is required")
    
    try:
        session_time = datetime.fromisoformat(session_time_str) if session_time_str else datetime.now()
    except ValueError:
        session_time = datetime.now()
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Create a unique session ID based on date and hour-minute
    session_id = f"{session_time.date()}_{session_time.hour}_{session_time.minute}"
    
    # Find or create session record in MongoDB
    session_record = attendance_collection.find_one({"session_id": session_id})
    
    if not session_record:
        all_names = list(db.keys())
        session_record = {
            "session_id": session_id,
            "date": session_time.strftime("%Y-%m-%d"),
            "start_time": session_time.strftime("%H:%M"),
            "present": [],
            "absent": all_names
        }
        result = attendance_collection.insert_one(session_record)
        session_record['_id'] = result.inserted_id
    
    if name not in session_record["present"]:
        # Update the record in MongoDB
        attendance_collection.update_one(
            {"_id": session_record["_id"]},
            {
                "$addToSet": {"present": name},
                "$pull": {"absent": name}
            }
        )
        
        # Update in-memory records
        updated_record = attendance_collection.find_one({"_id": session_record["_id"]}, {'_id': 0})
        updated_record['session_id'] = str(updated_record['_id'])
        
        return {"status": "success", "message": f"{name} marked present at {timestamp}"}
    
    return {"status": "info", "message": f"{name} already marked in this session"}

@app.get("/attendance")
async def get_attendance():
    records = list(attendance_collection.find({}, {'_id': 0}))
    # Convert ObjectId to string for JSON serialization
    for record in records:
        if 'session_id' in record:
            record['session_id'] = str(record['session_id'])
    return {"status": "success", "data": records}

@app.get("/students")
async def get_students():
    names = [record['name'] for record in embeddings_collection.find({}, {'name': 1})]
    return {"status": "success", "data": names}

@app.delete("/students/{student_name}")
async def delete_student(student_name: str):
    # Check if student exists
    if not embeddings_collection.find_one({"name": student_name}):
        raise HTTPException(status_code=404, detail="Student not found")
    
    try:
        # Remove student from embeddings
        embeddings_collection.delete_one({"name": student_name})
        
        # Remove student's face image
        faces_collection.delete_one({"name": student_name})
        
        # Update attendance records
        attendance_collection.update_many(
            {},
            {
                "$pull": {
                    "present": student_name,
                    "absent": student_name
                }
            }
        )
        
        # Remove empty attendance records
        attendance_collection.delete_many({
            "present": {"$size": 0},
            "absent": {"$size": 0}
        })
        
        # Update in-memory db
        if student_name in db:
            del db[student_name]
        
        return {"status": "success", "message": f"Student {student_name} deleted successfully"}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting student: {str(e)}")

@app.delete("/reset-all")
async def reset_all_data():
    try:
        # Reset all collections
        embeddings_collection.delete_many({})
        attendance_collection.delete_many({})
        faces_collection.delete_many({})
        
        # Update in-memory db
        db.clear()
        
        return {"status": "success", "message": "All data reset successfully"}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error resetting data: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="192.100.35.140", port=8000)